<?php

require_once "filemanager/dialog.php";

?>